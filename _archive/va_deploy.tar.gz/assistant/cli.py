"""Командная строка.

    python -m assistant.cli import-csv [--user Имя] [--path файл.csv] [--no-embed]
    python -m assistant.cli embed [--user Имя]
    python -m assistant.cli export-ics [--user Имя] --out calendar.ics
    python -m assistant.cli import-ics файл.ics [--user Имя]
    python -m assistant.cli stats
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .config import Settings
from .providers import build_context
from .services import ics
from .services.importer import import_csv


def main(argv: list[str] | None = None) -> int:
    settings = Settings.from_env()
    p = argparse.ArgumentParser(prog="python -m assistant.cli")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("import-csv", help="Импорт истории прошлых запросов из CSV")
    a.add_argument("--user", default=settings.default_user)
    a.add_argument("--path", default=str(settings.history_csv))
    a.add_argument("--no-embed", action="store_true", help="Не считать эмбеддинги сейчас")

    e = sub.add_parser("embed", help="Досчитать эмбеддинги для поиска по смыслу")
    e.add_argument("--user", default=settings.default_user)

    x = sub.add_parser("export-ics", help="Выгрузить записи в .ics")
    x.add_argument("--user", default=settings.default_user)
    x.add_argument("--out", default="calendar.ics")

    i = sub.add_parser("import-ics", help="Загрузить события из .ics")
    i.add_argument("path")
    i.add_argument("--user", default=settings.default_user)

    sub.add_parser("stats", help="Пользователи и количество записей")
    args = p.parse_args(argv)

    ctx = build_context(settings)

    def embed(user_id: int) -> None:
        if ctx.search.index is None:
            print("OPENAI_API_KEY не задан: эмбеддинги будут посчитаны позже, когда появится ключ. "
                  "Поиск пока работает по словам.")
            return
        n = ctx.search.ensure_embeddings(user_id)
        print(f"Эмбеддинги готовы для {n} записей (запросов к API: {ctx.search.index.api_calls}, "
              f"остальное из кэша).")

    if args.cmd == "stats":
        for u in ctx.repo.list_users():
            print(f"{u['id']}: {u['name']} - записей {ctx.repo.count_items(u['id'])}, "
                  f"из истории {ctx.repo.count_items(u['id'], 'import')}")
        print(f"Векторов в кэше: {ctx.repo.count_vectors()}")
        return 0

    user = ctx.repo.get_or_create_user(args.user)
    if args.cmd == "import-csv":
        stats = import_csv(ctx.repo, user["id"], Path(args.path), settings.meeting_default_minutes)
        print(f"Пользователь «{user['name']}»: строк {stats['rows']}, добавлено {stats['inserted']}, "
              f"уже были {stats['skipped_existing']}, с ошибками {stats['invalid']}")
        if not args.no_embed:
            embed(user["id"])
    elif args.cmd == "embed":
        embed(user["id"])
    elif args.cmd == "export-ics":
        Path(args.out).write_bytes(ics.export_ics(ctx.repo.list_items(user["id"]), settings.timezone,
                                                  settings.meeting_default_minutes))
        print(f"Сохранено: {args.out}")
    elif args.cmd == "import-ics":
        print(ics.import_ics(ctx.repo, user["id"], Path(args.path).read_bytes(), settings.timezone))
    return 0


if __name__ == "__main__":
    sys.exit(main())
