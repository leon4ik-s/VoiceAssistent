"""Настройки приложения: читаются из переменных окружения и файла .env."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


class ConfigError(RuntimeError):
    """Ошибка конфигурации, понятная пользователю (например, не задан ключ API)."""


def _bool(value: str | None, default: bool) -> bool:
    if value is None or value.strip() == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on", "да"}


def _path(value: str | None, default: Path) -> Path:
    if not value:
        return default
    p = Path(value)
    return p if p.is_absolute() else BASE_DIR / p


@dataclass
class Settings:
    openai_api_key: str = ""
    openai_base_url: str | None = None
    chat_model: str = "gpt-4o-mini"
    stt_model: str = "whisper-1"
    tts_model: str = "gpt-4o-mini-tts"
    tts_voice: str = "alloy"
    embed_model: str = "text-embedding-3-small"
    embed_batch_size: int = 100
    timezone: str = "Europe/Moscow"
    db_path: Path = field(default_factory=lambda: BASE_DIR / "data" / "assistant.db")
    default_user: str = "Основной"
    import_csv_on_start: bool = True
    history_csv: Path = field(
        default_factory=lambda: BASE_DIR / "data" / "voice_assistant_events_1000_77e927b5d2.csv"
    )
    meeting_default_minutes: int = 60
    history_messages: int = 12
    host: str = "127.0.0.1"
    port: int = 8000

    @property
    def openai_configured(self) -> bool:
        return bool(self.openai_api_key.strip())

    @classmethod
    def from_env(cls, env_file: Path | None = None) -> "Settings":
        try:
            from dotenv import load_dotenv

            load_dotenv(env_file or BASE_DIR / ".env", override=False)
        except ImportError:  # pragma: no cover
            pass
        e = os.environ.get
        d = cls()
        return cls(
            openai_api_key=e("OPENAI_API_KEY", "").strip(),
            openai_base_url=(e("OPENAI_BASE_URL") or "").strip() or None,
            chat_model=e("OPENAI_CHAT_MODEL") or d.chat_model,
            stt_model=e("OPENAI_STT_MODEL") or d.stt_model,
            tts_model=e("OPENAI_TTS_MODEL") or d.tts_model,
            tts_voice=e("OPENAI_TTS_VOICE") or d.tts_voice,
            embed_model=e("OPENAI_EMBED_MODEL") or d.embed_model,
            embed_batch_size=int(e("EMBED_BATCH_SIZE") or d.embed_batch_size),
            timezone=e("APP_TIMEZONE") or d.timezone,
            db_path=_path(e("DB_PATH"), d.db_path),
            default_user=e("DEFAULT_USER") or d.default_user,
            import_csv_on_start=_bool(e("IMPORT_CSV_ON_START"), d.import_csv_on_start),
            history_csv=_path(e("HISTORY_CSV"), d.history_csv),
            meeting_default_minutes=int(e("MEETING_DEFAULT_MINUTES") or d.meeting_default_minutes),
            history_messages=int(e("HISTORY_MESSAGES") or d.history_messages),
            host=e("HOST") or d.host,
            port=int(e("PORT") or d.port),
        )
