"""Клиент языковой модели. Интерфейс заменяемый: в тестах используется фейковая реализация."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict


@dataclass
class LLMResponse:
    content: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)

    def as_message(self) -> dict:
        """Сообщение ассистента в формате Chat Completions (для продолжения диалога с инструментами)."""
        msg: dict[str, Any] = {"role": "assistant", "content": self.content or ""}
        if self.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {"name": tc.name, "arguments": json.dumps(tc.arguments, ensure_ascii=False)},
                }
                for tc in self.tool_calls
            ]
        return msg


class LLMClient(Protocol):
    def chat(self, messages: list[dict], tools: list[dict]) -> LLMResponse: ...


class OpenAIChat:
    """GPT с function calling (tools)."""

    def __init__(self, client, model: str, temperature: float = 0.2):
        self.client = client
        self.model = model
        self.temperature = temperature

    def chat(self, messages: list[dict], tools: list[dict]) -> LLMResponse:
        kwargs = {}
        if self.model.startswith(("gpt-4", "gpt-3")):  # у reasoning-моделей температура фиксирована
            kwargs["temperature"] = self.temperature
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            **kwargs,
        )
        msg = resp.choices[0].message
        calls = []
        for tc in msg.tool_calls or []:
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {"_raw": tc.function.arguments}
            calls.append(ToolCall(id=tc.id, name=tc.function.name, arguments=args))
        return LLMResponse(content=msg.content, tool_calls=calls)
