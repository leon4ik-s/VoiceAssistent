"""Описание инструментов (function calling) и их выполнение через бизнес-логику."""
from __future__ import annotations

from typing import Any

from ..services.scheduler import Scheduler

KIND_ENUM = ["task", "reminder", "meeting"]

RECURRENCE_SCHEMA = {
    "type": "object",
    "description": "Правило повтора. Не передавать, если событие разовое.",
    "properties": {
        "freq": {"type": "string", "enum": ["daily", "weekly", "monthly", "yearly", "weekdays"],
                 "description": "weekdays = по будням (пн-пт)"},
        "interval": {"type": "integer", "description": "Каждые N периодов, по умолчанию 1"},
        "weekdays": {"type": "array", "items": {"type": "string", "enum": ["MO", "TU", "WE", "TH", "FR", "SA", "SU"]},
                     "description": "Дни недели для weekly"},
        "until": {"type": "string", "description": "Дата окончания YYYY-MM-DD"},
        "count": {"type": "integer", "description": "Количество повторов"},
    },
    "required": ["freq"],
}

REF_PROPS = {
    "item_id": {"type": "integer", "description": "id записи, если известен (из контекста или результатов поиска)"},
    "query": {"type": "string", "description": "Описание записи словами, если id неизвестен"},
}


def _fn(name: str, description: str, properties: dict, required: list[str] | None = None) -> dict:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {"type": "object", "properties": properties, "required": required or []},
        },
    }


TOOLS: list[dict] = [
    _fn(
        "create_item",
        "Создать задачу, напоминание или встречу. Вызывай только когда известны название и дата "
        "(для встречи и напоминания еще и время). Не выдумывай недостающие данные.",
        {
            "kind": {"type": "string", "enum": KIND_ENUM},
            "title": {"type": "string", "description": "Короткое название без даты и времени"},
            "date": {"type": "string", "description": "Дата YYYY-MM-DD"},
            "time": {"type": "string", "description": "Время HH:MM (24ч)"},
            "duration_min": {"type": "integer", "description": "Длительность встречи в минутах"},
            "recurrence": RECURRENCE_SCHEMA,
            "force": {"type": "boolean", "description": "true - создать несмотря на пересечение встреч"},
        },
        ["kind", "title"],
    ),
    _fn(
        "update_item",
        "Изменить запись: название, дату, время, длительность, повтор. Если пользователь говорит "
        "«ее», «его», «эту» - это последняя упомянутая запись из контекста.",
        {
            **REF_PROPS,
            "title": {"type": "string"},
            "date": {"type": "string", "description": "Новая дата YYYY-MM-DD"},
            "time": {"type": "string", "description": "Новое время HH:MM"},
            "duration_min": {"type": "integer"},
            "kind": {"type": "string", "enum": KIND_ENUM},
            "recurrence": RECURRENCE_SCHEMA,
            "clear_recurrence": {"type": "boolean", "description": "Сделать событие разовым"},
            "force": {"type": "boolean", "description": "true - перенести несмотря на пересечение"},
        },
    ),
    _fn("delete_item", "Удалить запись (для повторяющейся - всю серию).", dict(REF_PROPS)),
    _fn(
        "complete_item",
        "Отметить задачу выполненной (done=false - вернуть в работу). Для повторяющейся отмечается один экземпляр.",
        {
            **REF_PROPS,
            "done": {"type": "boolean", "description": "по умолчанию true"},
            "occurrence_date": {"type": "string", "description": "Дата экземпляра повторяющейся задачи"},
        },
    ),
    _fn(
        "list_schedule",
        "Показать расписание за период (включительно).",
        {
            "date_from": {"type": "string", "description": "YYYY-MM-DD"},
            "date_to": {"type": "string", "description": "YYYY-MM-DD"},
            "kind": {"type": "string", "enum": KIND_ENUM, "description": "Фильтр по типу"},
            "include_done": {"type": "boolean"},
        },
        ["date_from", "date_to"],
    ),
    _fn(
        "search_items",
        "Поиск записей по смыслу, в том числе в истории прошлых запросов. Используй для вопросов "
        "«что у меня было про...», «когда была...», и чтобы найти id записи перед правкой.",
        {
            "query": {"type": "string", "description": "Смысл запроса своими словами, без слов вроде «когда была»"},
            "date_from": {"type": "string"},
            "date_to": {"type": "string"},
            "kind": {"type": "string", "enum": KIND_ENUM},
            "limit": {"type": "integer", "description": "по умолчанию 10"},
        },
        ["query"],
    ),
]


def _kinds(args: dict) -> list[str] | None:
    k = args.get("kind")
    return [k] if k in KIND_ENUM else None


def execute(scheduler: Scheduler, user_id: int, name: str, args: dict, recent_ids: list[int]) -> dict[str, Any]:
    """Выполнить инструмент. Ошибки возвращаются модели как данные, чтобы она могла переспросить."""
    a = {k: v for k, v in (args or {}).items() if v not in (None, "")}
    try:
        if name == "create_item":
            return scheduler.create(user_id, a.get("kind", ""), a.get("title"), a.get("date"), a.get("time"),
                                    a.get("duration_min"), a.get("recurrence"), bool(a.get("force")))
        if name == "update_item":
            return scheduler.update(user_id, a.get("item_id"), a.get("query"), recent_ids,
                                    title=a.get("title"), date=a.get("date"), time=a.get("time"),
                                    duration_min=a.get("duration_min"), kind=a.get("kind"),
                                    recurrence_rule=a.get("recurrence"),
                                    clear_recurrence=bool(a.get("clear_recurrence")), force=bool(a.get("force")))
        if name == "delete_item":
            return scheduler.delete(user_id, a.get("item_id"), a.get("query"), recent_ids)
        if name == "complete_item":
            return scheduler.complete(user_id, a.get("item_id"), a.get("query"), recent_ids,
                                      done=a.get("done", True), occurrence_date=a.get("occurrence_date"))
        if name == "list_schedule":
            items = scheduler.schedule(user_id, a["date_from"], a.get("date_to"), _kinds(a),
                                       a.get("include_done", True))
            return {"status": "ok", "count": len(items), "items": items[:100],
                    "truncated": len(items) > 100}
        if name == "search_items":
            return scheduler.search(user_id, a.get("query", ""), a.get("date_from"), a.get("date_to"),
                                    _kinds(a), a.get("limit", 10))
        return {"status": "error", "message": f"Неизвестный инструмент {name}"}
    except (ValueError, KeyError, TypeError) as exc:
        return {"status": "error", "message": f"Некорректные параметры: {exc}"}


def touched_ids(name: str, result: dict) -> list[int]:
    """id записей, которые стоит запомнить как «последние упомянутые»."""
    if result.get("status") == "ok":
        if result.get("action") == "deleted":
            return []
        if "item" in result:
            return [result["item"]["id"]]
        if name == "search_items":
            return [r["id"] for r in result.get("results", [])[:3]]
        if name == "list_schedule" and result.get("count", 0) == 1:
            return [result["items"][0]["id"]]
    if result.get("status") in ("conflict", "need_clarification") and "item" in result:
        return [result["item"]["id"]]
    return []
