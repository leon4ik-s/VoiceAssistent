"""Сборка внешних сервисов (OpenAI) и всего приложения из настроек.

Все обращения к OpenAI идут через объекты с простыми интерфейсами
(LLMClient, SpeechToText, TextToSpeech, Embedder), поэтому их легко заменить
фейками в тестах или другим провайдером.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .config import ConfigError, Settings
from .nlu.agent import Assistant
from .nlu.llm import LLMClient, OpenAIChat
from .services.scheduler import Scheduler
from .services.search import SemanticSearch
from .storage.db import Database
from .storage.embeddings import Embedder, EmbeddingIndex
from .storage.repository import Repository
from .voice.speech import OpenAISpeechToText, OpenAITextToSpeech, SpeechToText, TextToSpeech

NO_KEY_MESSAGE = (
    "Не задан ключ OpenAI. Впишите OPENAI_API_KEY в файл .env в папке проекта и перезапустите сервер. "
    "Просмотр расписания работает и без ключа."
)


class OpenAIEmbedder:
    def __init__(self, client, model: str):
        self.client = client
        self.model = model

    def embed(self, texts: list[str]) -> list[list[float]]:
        resp = self.client.embeddings.create(model=self.model, input=texts)
        return [d.embedding for d in sorted(resp.data, key=lambda d: d.index)]


@dataclass
class Providers:
    """Фабрики внешних сервисов. Если сервис недоступен (нет ключа) - фабрика бросает ConfigError."""

    llm: Callable[[], LLMClient]
    stt: Callable[[], SpeechToText]
    tts: Callable[[], TextToSpeech]
    embedder: Embedder | None  # None - семантическая часть поиска отключена


def openai_providers(settings: Settings) -> Providers:
    if not settings.openai_configured:
        def missing():
            raise ConfigError(NO_KEY_MESSAGE)

        return Providers(llm=missing, stt=missing, tts=missing, embedder=None)

    from openai import OpenAI

    client = OpenAI(api_key=settings.openai_api_key, base_url=settings.openai_base_url, timeout=60, max_retries=2)
    llm = OpenAIChat(client, settings.chat_model)
    stt = OpenAISpeechToText(client, settings.stt_model)
    tts = OpenAITextToSpeech(client, settings.tts_model, settings.tts_voice)
    return Providers(llm=lambda: llm, stt=lambda: stt, tts=lambda: tts,
                     embedder=OpenAIEmbedder(client, settings.embed_model))


@dataclass
class AppContext:
    settings: Settings
    db: Database
    repo: Repository
    search: SemanticSearch
    scheduler: Scheduler
    assistant: Assistant
    providers: Providers


def build_context(settings: Settings, providers: Providers | None = None, now_fn=None) -> AppContext:
    from datetime import datetime
    from zoneinfo import ZoneInfo

    providers = providers or openai_providers(settings)
    db = Database(settings.db_path)
    repo = Repository(db)
    index = EmbeddingIndex(repo, providers.embedder, settings.embed_batch_size) if providers.embedder else None
    search = SemanticSearch(repo, index)
    tz = ZoneInfo(settings.timezone)
    scheduler = Scheduler(repo, search, settings.meeting_default_minutes,
                          now_fn=now_fn or (lambda: datetime.now(tz)))
    assistant = Assistant(repo, scheduler, providers.llm, settings.timezone, settings.history_messages,
                          settings.meeting_default_minutes)
    return AppContext(settings, db, repo, search, scheduler, assistant, providers)
