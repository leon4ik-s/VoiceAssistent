"""Векторный индекс: эмбеддинги текстов с кэшем в SQLite.

Один и тот же текст для одной модели считается только один раз, поэтому
повторный импорт и повторный поиск не тратят запросы к API.
"""
from __future__ import annotations

import hashlib
import re
from typing import Protocol

import numpy as np

from .repository import Repository


class Embedder(Protocol):
    model: str

    def embed(self, texts: list[str]) -> list[list[float]]: ...


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def cache_key(model: str, text: str) -> str:
    return hashlib.sha256(f"{model}\n{normalize_text(text)}".encode("utf-8")).hexdigest()


class EmbeddingIndex:
    def __init__(self, repo: Repository, embedder: Embedder, batch_size: int = 100):
        self.repo = repo
        self.embedder = embedder
        self.batch_size = max(1, batch_size)
        self.api_calls = 0  # для тестов и логов

    def vectors_for(self, texts: list[str]) -> dict[str, np.ndarray]:
        """Вернуть {текст: нормированный вектор}; недостающие посчитать батчами и закэшировать."""
        model = self.embedder.model
        uniq = list(dict.fromkeys(normalize_text(t) for t in texts if t and t.strip()))
        keys = {t: cache_key(model, t) for t in uniq}
        cached = self.repo.get_vectors(list(keys.values()))
        missing = [t for t in uniq if keys[t] not in cached]
        for i in range(0, len(missing), self.batch_size):
            batch = missing[i : i + self.batch_size]
            vecs = self.embedder.embed(batch)
            self.api_calls += 1
            fresh = {keys[t]: np.asarray(v, dtype=np.float32) for t, v in zip(batch, vecs)}
            self.repo.put_vectors(model, fresh)
            cached.update(fresh)
        out = {}
        for t in uniq:
            v = cached[keys[t]]
            n = float(np.linalg.norm(v))
            out[t] = v / n if n else v
        return out
