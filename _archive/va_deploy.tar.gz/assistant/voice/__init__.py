"""Голосовой слой: STT и TTS."""
from .speech import OpenAISpeechToText, OpenAITextToSpeech, SpeechToText, TextToSpeech

__all__ = ["OpenAISpeechToText", "OpenAITextToSpeech", "SpeechToText", "TextToSpeech"]
