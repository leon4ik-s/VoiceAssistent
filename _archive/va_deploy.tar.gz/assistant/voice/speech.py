"""Голосовой слой: распознавание речи (STT) и озвучка ответов (TTS) через OpenAI."""
from __future__ import annotations

from typing import Protocol

MAX_TTS_CHARS = 4000
EXT_BY_MIME = {
    "audio/webm": "webm",
    "audio/ogg": "ogg",
    "audio/mp4": "mp4",
    "audio/x-m4a": "m4a",
    "audio/m4a": "m4a",
    "audio/mpeg": "mp3",
    "audio/wav": "wav",
    "audio/x-wav": "wav",
}


class SpeechToText(Protocol):
    def transcribe(self, audio: bytes, filename: str = "audio.webm", content_type: str | None = None) -> str: ...


class TextToSpeech(Protocol):
    def synthesize(self, text: str) -> bytes: ...


def guess_filename(filename: str | None, content_type: str | None) -> str:
    if filename and "." in filename:
        return filename
    base = (content_type or "").split(";")[0].strip().lower()
    return f"speech.{EXT_BY_MIME.get(base, 'webm')}"


class OpenAISpeechToText:
    def __init__(self, client, model: str = "whisper-1", language: str = "ru"):
        self.client = client
        self.model = model
        self.language = language

    def transcribe(self, audio: bytes, filename: str = "audio.webm", content_type: str | None = None) -> str:
        name = guess_filename(filename, content_type)
        result = self.client.audio.transcriptions.create(
            model=self.model,
            file=(name, audio, content_type or "application/octet-stream"),
            language=self.language,
            response_format="text",
        )
        text = result if isinstance(result, str) else getattr(result, "text", "")
        return (text or "").strip()


class OpenAITextToSpeech:
    def __init__(self, client, model: str = "gpt-4o-mini-tts", voice: str = "alloy"):
        self.client = client
        self.model = model
        self.voice = voice

    def synthesize(self, text: str) -> bytes:
        resp = self.client.audio.speech.create(
            model=self.model,
            voice=self.voice,
            input=text[:MAX_TTS_CHARS],
            response_format="mp3",
        )
        return resp.content
