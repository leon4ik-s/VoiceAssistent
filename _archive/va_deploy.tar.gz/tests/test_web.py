"""HTTP API: страница, ошибки без ключа, чат, голос, экспорт."""
import pytest
from fastapi.testclient import TestClient

from assistant.web.app import create_app

from conftest import NOW, ScriptedLLM


@pytest.fixture
def client(settings, providers):
    app = create_app(settings, providers, now_fn=lambda: NOW)
    with TestClient(app) as c:
        yield c
    app.state.ctx.db.close()


@pytest.fixture
def no_key_client(settings, no_key_providers):
    settings.openai_api_key = ""
    app = create_app(settings, no_key_providers, now_fn=lambda: NOW)
    with TestClient(app) as c:
        yield c
    app.state.ctx.db.close()


def default_user(c):
    return c.get("/api/users").json()[0]["id"]


def test_index_and_status(client):
    r = client.get("/")
    assert r.status_code == 200 and "Голосовой ассистент" in r.text
    st = client.get("/api/status").json()
    assert st["openai"] is True and st["users"][0]["name"] == "Основной"


def test_no_key_returns_readable_error(no_key_client):
    c = no_key_client
    uid = default_user(c)
    st = c.get("/api/status").json()
    assert st["openai"] is False and "OPENAI_API_KEY" in st["message"]
    r = c.post("/api/chat", json={"user_id": uid, "text": "Привет"})
    assert r.status_code == 503 and "ключ" in r.json()["error"].lower()
    r = c.post("/api/voice", data={"user_id": uid}, files={"audio": ("a.webm", b"x" * 2000, "audio/webm")})
    assert r.status_code == 503
    assert c.get(f"/api/schedule?user_id={uid}").status_code == 200   # расписание работает без ключа


def test_chat_and_voice(client, llm_holder):
    uid = default_user(client)
    llm_holder["llm"] = ScriptedLLM([
        [("create_item", {"kind": "reminder", "title": "Позвонить Ивану", "date": "2026-10-31", "time": "09:00"})],
        "Напомню завтра в 9 утра позвонить Ивану.",
    ])
    r = client.post("/api/voice", data={"user_id": uid, "speak_reply": "true"},
                    files={"audio": ("speech.webm", b"x" * 2000, "audio/webm")})
    body = r.json()
    assert r.status_code == 200 and body["transcript"] and body["changed"] and body["audio"]
    items = client.get(f"/api/schedule?user_id={uid}&date_from=2026-10-31&date_to=2026-10-31").json()
    assert [i["title"] for i in items] == ["Позвонить Ивану"]

    llm_holder["llm"] = ScriptedLLM(["Завтра в 9 звонок Ивану."])
    r = client.post("/api/chat", json={"user_id": uid, "text": "Что у меня завтра?"})
    assert r.json()["reply"] == "Завтра в 9 звонок Ивану." and "audio" not in r.json()
    hist = client.get(f"/api/history?user_id={uid}").json()
    assert [m["role"] for m in hist] == ["user", "assistant", "user", "assistant"]


def test_items_users_and_ics(client):
    uid = default_user(client)
    ctx = client.app.state.ctx
    item = ctx.scheduler.create(uid, "task", "Отчет", "2026-10-31", "12:00")["item"]
    assert client.post(f"/api/items/{item['id']}/complete?user_id={uid}").json()["item"]["status"] == "done"
    other = client.post("/api/users", json={"name": "Гость"}).json()
    assert client.delete(f"/api/items/{item['id']}?user_id={other['id']}").status_code == 404
    r = client.get(f"/api/export.ics?user_id={uid}")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/calendar") and b"VEVENT" in r.content
    r = client.post("/api/import/ics", data={"user_id": other["id"]}, files={"file": ("c.ics", r.content, "text/calendar")})
    assert r.json()["created"] == 1
    assert client.delete(f"/api/items/{item['id']}?user_id={uid}").status_code == 200


def test_history_import_on_startup(settings, providers):
    settings.import_csv_on_start = True
    for _ in range(2):  # второй запуск не создает дублей
        app = create_app(settings, providers, now_fn=lambda: NOW)
        with TestClient(app) as c:
            uid = default_user(c)
            assert app.state.ctx.repo.count_items(uid, "import") == 1000
        for t in app.state.embed_threads:
            t.join(timeout=10)
        app.state.ctx.db.close()
